<?php

use Illuminate\Support\Facades\Route;

Route::get('admin', 'AdminController@welcome');
