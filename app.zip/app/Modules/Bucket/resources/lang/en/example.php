<?php

return [
    'welcome' => 'Welcome, this is Bucket module.'
];
