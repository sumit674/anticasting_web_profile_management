<?php

return [
    'welcome' => 'Welcome, this is Settings module.'
];
