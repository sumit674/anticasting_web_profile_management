
<?php $__env->startSection('title'); ?>
   Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('assets/auth/jquery-3.6.0.js')); ?>"></script>
<script src="<?php echo e(asset('assets/auth/toastr.min.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/auth/toastr.min.css')); ?>">
<div class="main">
    <script>
        <?php if(Session::has('message')): ?>
           toastr.success("<?php echo e(Session::get('message')); ?>");
           <?php elseif(Session::has('error')): ?>
             toastr.error("<?php echo e(Session::get('error')); ?>");
         <?php endif; ?>
     </script>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8 p-r-0 title-margin-right">
                <div class="page-header">
                    <div class="page-title">
                        <h1>Hello, <span>Welcome Here</span></h1>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 p-l-0 title-margin-left">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Home</li>
                        </ol>
                    </div>
                </div>
            </div>

        </div>
        <!-- /# row -->
        <section id="main-content">
            <div class="row">
                
                <div class="col-lg-3">
                    <div class="card">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-user color-primary border-primary"></i>
                            </div>
                            <div class="stat-content dib">
                                <div class="stat-text">Actors</div>
                                <div class="stat-digit">961</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-layout-grid2 color-pink border-pink"></i>
                            </div>
                            <div class="stat-content dib">
                                <div class="stat-text">Active Projects</div>
                                <div class="stat-digit">770</div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        
         


            <div class="row" style="bottom: 0; position: fixed;">
                <div class="col-lg-12">
                    <div class="footer">
                        <p><?php echo e(Carbon\Carbon::now()->year); ?> © Admin Dashboard <a class="nav-item" href="https://sascoders.com/" target="__blank">SASCoders</a></p>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\anticasting_web_profile_management\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>