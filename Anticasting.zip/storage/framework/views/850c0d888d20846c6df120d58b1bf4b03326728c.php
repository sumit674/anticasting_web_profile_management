<div class="container">
    <div class="bg-white rounded d-flex align-items-center justify-content-between" id="header">
        <?php echo $__env->make('Actors::profiles.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div id="content" class="my-3">
        <?php echo $__env->make('Actors::profiles.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="products">
            <div class="row mx-0">
                <?php
                    $avgrating = 0;
                ?>
                <?php if(isset($actors)): ?>
                    <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $dateOfBirth = $item?->profile?->date_of_birth;
                            //$age = \Carbon\Carbon::parse($dateOfBirth)->diff(\Carbon\Carbon::now())->format('%y years, %m months and %d days'); //\Carbon\Carbon::parse($dateOfBirth)->age;
                            $age = \Carbon\Carbon::parse($dateOfBirth)
                                ->diff(\Carbon\Carbon::now())
                                ->format('%y years');
                        ?>
                        <div class="col-lg-3 col-sm-6 col-md-6 pt-md-0 pt-3">
                            <div class="card d-flex flex-column align-items-center actor-grid">
                                <div class="card-img c-card__image-container">
                                    <div style="cursor: pointer;" data-toggle="popover" >
                                        <?php if(isset($item->images[0]->image)): ?>
                                            <a href="<?php echo e(route('admin.profile-detail', $item->id)); ?>" target="__blank">
                                                <img class="c-card__image" src="<?php echo e($item->images[0]?->image); ?>" />
                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('admin.profile-detail', $item->id)); ?>">
                                                <img class="c-card__image"
                                                    src="https://source.unsplash.com/random/234x156/?nature" />
                                            </a>
                                        <?php endif; ?>
                                        
                                    </div>
                                  <div>
                                        <label class="product-discount-label check-container"
                                            for="actor-<?php echo e($item->id); ?>">
                                            
                                            <input type="checkbox" name="actor" id="actor-<?php echo e($item->id); ?>"
                                                value="<?php echo e($item->id); ?>" class="actor-item"
                                                data-id="<?php echo e($item->id); ?>"
                                               />
                                            
                                            <span class="mark"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="c-card__content">
                                    <div class="c-card__name">
                                        <label><a
                                                href="<?php echo e(route('admin.profile-detail', [$item?->id])); ?>"class="c-card__name-link"
                                                target="_blank"><?php echo e($item?->first_name . ' ' . $item?->last_name); ?></a></label>
                                    </div>
                                    <div class="c-card__title">
                                        <label>Mobile no:</label> <?php echo e($item?->mobile_no); ?>

                                    </div>
                                    <div class="c-card__title">
                                        <label>Age:</label> <?php echo e($age); ?>

                                    </div>
                                    <div class="c-card__title">
                                        <label>Height:</label>
                                        <?php echo e($item?->profile?->height . ' ' . ' '); ?> cm
                                    </div>
                                    <div class="c-card__title">
                                        <label>Weight:</label> <?php echo e($item?->profile?->weight . ' ' . ' '); ?>kg
                                    </div>

                                    <div class="d-flex align-items-center justify-content-center colors my-2">
                                        <div class="price">
                                            <span style="cursor: pointer;" data-toggle="popover"
                                                data-poload="<?php echo e(route('admin.actors.video', $item->id)); ?>">
                                                <i class="fa fa-video-camera fa-2x" aria-hidden="true"></i>
                                            </span>
                                            &nbsp;&nbsp;
                                            <span style="cursor: pointer;" data-toggle="popover"
                                                >
                                                <a href="<?php echo e(route('admin.profile-detail', $item->id)); ?>" target="__blank">
                                                <i class="fa-solid fa-eye fa-2x" aria-hidden="true"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>


                                    
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<script>
       $('body').on('click', function(e) {
            $('[data-toggle="popover"]').each(function() {
                if (!$(this).is(e.target) &&
                    $(this).has(e.target).length === 0 &&
                    $('.popover').has(e.target).length === 0) {
                    $(this).popover('hide');
                }
            });
        });
        // $('[data-toggle="popover"]').on('click', function(e) {
        //     $('[data-toggle="popover"]').not(this).popover('hide');
        // });
        $('*[data-poload]').click(function() {
            var e = $(this);
            // e.off('click');
            $.get(e.data('poload'), function(d) {
                e.popover({
                    html: true,
                    placement: "bottom",
                    container: 'body',
                    trigger: 'focus',
                    content: d
                }).popover('show');
            });
        });
 </script>   <?php /**PATH F:\wamp64\www\anticasting_web_profile_management\app\Modules/Actors/resources/views/profiles/rating-filter.blade.php ENDPATH**/ ?>