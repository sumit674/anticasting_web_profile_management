<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website <?php echo e(\Carbon\Carbon::now()->year); ?></span>
        </div>
    </div>
</footer><?php /**PATH F:\wamp64\www\anticasting_web_profile_management\resources\views/front-dashboard/include/footer.blade.php ENDPATH**/ ?>