<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('header'); ?>
    <?php echo $__env->yieldPushContent('style'); ?>
</head>

<body>
    <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <div class="content-wrap">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
  
     <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
     <script src="<?php echo e(asset('assets/admin/js/lib/bootstrap.min.js')); ?>"  crossorigin="anonymous"></script>
     <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
     <script  src="<?php echo e(asset('assets/admin/js/fSelect.js')); ?>"></script>
     <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote-bs4.js"></script>
     <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
     
    <?php echo $__env->yieldContent('footer'); ?>
  </body>
</html>
<?php /**PATH F:\wamp64\www\anticasting_web_profile_management\resources\views/admin/layouts/admin_master.blade.php ENDPATH**/ ?>