
<?php $__env->startSection('title'); ?>
    Setting
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('assets/auth/toastr.min.js')); ?>" defer ></script>
<script src="<?php echo e(asset('assets/auth/jquery-3.6.0.js')); ?>"></script>
<div class="main">
    <script>
        <?php if(Session::has('message')): ?>
           toastr.success("<?php echo e(Session::get('message')); ?>");
           <?php elseif(Session::has('error')): ?>
             toastr.error("<?php echo e(Session::get('error')); ?>");
         <?php endif; ?>
      </script>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8 p-r-0 title-margin-right">
                <div class="page-header">
                    <div class="page-title">
                        <h1>Settings</h1>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 p-l-0 title-margin-left">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Setting</li>
                        </ol>
                    </div>
                </div>
            </div>

        </div>

        <!-- /# row -->
        <section id="main-content">

            <div class="row">

                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-title">
                            <h4>Setting : Main Information</h4>
                        </div>
                        <div class="card-body">
                            <div class="basic-form">
                                <form action="<?php echo e(route('admin.UpdateSettingMainInfo')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><b> Site Title</b> <span style="color:red;"><b>*</b></span></label>
                                                <input type="text" class="form-control" name="site_title" placeholder="Site Title" value="<?php echo e(old('site_title',$site_title)); ?>" />
                                                <?php $__errorArgs = ['site_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                   <span style="color:red;"><b><?php echo e($message); ?></b></span> 
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="reward"><b>Site Email </b> <span style="color:red;"><b>*</b></span></label>
                                                <input type="text" class="form-control" name="site_email" placeholder="Site Email" value="<?php echo e(old('site_email',$site_email)); ?>" />
                                                <?php $__errorArgs = ['site_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span> 
                                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><b>Site Url</b> <span style="color:red;"><b>*</b></span></label>
                                                <input type="text" class="form-control" name="site_url" placeholder="Site Url" value="<?php echo e(old('site_url',$site_url)); ?>" />
                                                <?php $__errorArgs = ['site_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span> 
                                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="reward"><b>Site Address</b> <span style="color:red;"><b>*</b></span></label>
                                                <input type="text" class="form-control" name="address" placeholder="Site Address" value="<?php echo e(old('address',$address)); ?>" />
                                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span> 
                                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Update</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\anticasting_web_profile_management\app\Modules/Settings/resources/views/index.blade.php ENDPATH**/ ?>