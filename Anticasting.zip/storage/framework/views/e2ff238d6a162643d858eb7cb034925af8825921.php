<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Anticasting <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" sizes="16x16" href="<?php echo e(asset('assets/website/images/favicon.ico')); ?>">
    <?php echo $__env->make('include.submitprofile.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('style'); ?>
    <?php echo $__env->make('include.submitprofile.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    <!-- ======= Header ======= -->
    <?php echo $__env->yieldContent('header'); ?>
    <!-- ======= End Header ======= -->
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('include.submitprofile.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="<?php echo e(asset('assets/submitprofile/assets/js/bootstrap.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>

</body>
</html>
    <?php echo $__env->yieldContent('footer'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $(".form-disable").on("submit", function () {
                var self = $(this),
                    button = self.find('input[type="submit"], button'),
                    submitValue = button.data("submit-value");
                button
                    .attr("disabled", "disabled")
                    .val(submitValue ? submitValue : "Please wait...");
            });
        });
    </script>
</body>
</html>
<?php /**PATH F:\wamp64\www\anticasting_web_profile_management\resources\views/layouts/submit-profile-new.blade.php ENDPATH**/ ?>