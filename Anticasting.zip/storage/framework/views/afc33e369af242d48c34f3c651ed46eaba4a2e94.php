<button class="btn btn-hide text-uppercase" type="button" data-toggle="collapse" data-target="#filterbar"
    aria-expanded="false" aria-controls="filterbar" id="filter-btn" >
    
    <span class="fa fa-filter fa-2x" aria-hidden="true" id="filter-angle"></span>
    
</button>
<nav class="navbar navbar-expand-lg navbar-light pl-lg-0 pl-auto">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynav" aria-controls="mynav"
        aria-expanded="false" aria-label="Toggle navigation" onclick="chnageIcon()" id="icon"> <span
            class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse" id="mynav">
        <form action="" method="get">
            <ul class="navbar-nav d-lg-flex align-items-lg-center">
                <li class="nav-item active">
                    <select name="sort" id="sort">
                        <option value="" hidden selected>Sort by</option>
                        <option value="latest">Latest</option>
                        <option value="oldest">Oldest</option>
                    </select>
                </li>
                <li class="nav-item d-inline-flex align-items-center justify-content-between mb-lg-0 mb-3">
                    
                    <div class="font-weight-bold mx-2 result"><?php echo e($actors->count()); ?> from <?php echo e($actors->total()); ?></div>
                </li>
                <li class="nav-item d-lg-none d-inline-flex"> </li>
            </ul>
        </form>
    </div>
</nav>
<div class="ml-auto mt-1 mr-2">
    <nav aria-label="Page navigation example">
        <ul class="pagination">
            
            
            <li class="page-item">
                <?php echo e($actors->links('Actors::pagination')); ?>

            </li>
            
        </ul>
    </nav>
</div>
<?php /**PATH F:\wamp64\www\anticasting_web_profile_management\app\Modules/Actors/resources/views/profiles/topbar.blade.php ENDPATH**/ ?>