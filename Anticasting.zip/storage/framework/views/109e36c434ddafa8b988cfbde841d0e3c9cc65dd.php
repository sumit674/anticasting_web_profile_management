<link href="https://fonts.googleapis.com/css?family=Karla:400,700&display=swap" rel="stylesheet"/>
<link href="<?php echo e(asset('assets/auth/new-auth/css/materialdesignicons.min.css')); ?>" rel="stylesheet"/>

<link href="<?php echo e(asset('assets/users/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/auth/new-auth/css/style.css')); ?>" rel="stylesheet"/>
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/website/css/alertbox.css')); ?>"/>
<?php /**PATH F:\wamp64\www\anticasting_web_profile_management\resources\views/auth/include/head.blade.php ENDPATH**/ ?>