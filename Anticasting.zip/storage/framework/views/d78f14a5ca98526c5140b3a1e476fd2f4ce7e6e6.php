
<?php $__env->startSection('title'); ?>
    Actor Manage Actor
<?php $__env->stopSection(); ?>
<style>
    #contact_select {


        background: #FFF;
        color: #aaa;
    }
</style>

<?php $__env->startSection('content'); ?>
    <div class="main">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 p-r-0 title-margin-right">
                    <div class="page-header">
                        <div class="page-title">
                            <h1>Manage Actor</h1>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 p-l-0 title-margin-left">
                    <div class="page-header">
                        <div class="page-title">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active">Manage Actor</li>
                            </ol>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <section id="main-content">
        <?php if(Session::has('error')): ?>
            {
            <script>
                alert("<?php echo e(Session::get('error')); ?>");
            </script>
            }
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-title pr">
                        <h6><b class="breadcrumb-item">Create</b></h6>
                    </div>
                    <div class="card-body">
                        <hr />
                        <form action="<?php echo e(route('admin.actors.mange.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label" id="contact"><b>First name
                                            </b><span style="color:red;">*</span>
                                        </label>
                                        <input type="text" name="first_name" class="form-control"
                                            value="<?php echo e(old('first_name')); ?>" placeholder="Enter firstname" />
                                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label"><b>Last name
                                            </b><span style="color:red;">*</span>
                                        </label>
                                        <input type="text" name="last_name" class="form-control"
                                            value="<?php echo e(old('last_name')); ?>" placeholder="Enter lastname" />
                                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label" id="contact"><b>Mobile No</label>
                                        </b><span style="color:red;">*</span>
                                        <input type="tel" class="form-control" id="mobile_number" name="mobile_no"
                                            placeholder="Mobile number" />
                                        <input type="hidden" name="iso2" id="phone_country_code" value="+91" />
                                        <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label" for="email"><b>Email-ID
                                            </b>&nbsp;<span style="color:red;">*</span></label>
                                        <input type="email" name="email" class="form-control" id="email"
                                            placeholder="Enter email" value="<?php echo e(old('email')); ?>">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <label class="form-label" for="gender"><b>Ethnicity
                                            </b>&nbsp;<span style="color:red;">*</span></label>
                                        <select name="ethnicity" id="ethnicity" class="form-control">
                                            <option value="" selected="selected" class="0">
                                                Select Ethnicity
                                                <?php if(isset($state)): ?>
                                                    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->value); ?>">
                                                    <?php echo e($item->name); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['ethnicity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <label class="form-label" for="gender"><b>Gender
                                            </b>&nbsp;<span style="color:red;">*</span></label>
                                        <select name="gender" id="gender" class="form-control">
                                            <option value="" selected="selected" class="0">
                                                Select Gender
                                            </option>
                                            <option value="Male">
                                                Male</option>
                                            <option value="Female">
                                                Female</option>
                                            <option value="prefernottosay">
                                                Prefer not to say
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <label class="form-label" for="date_of_birth"><b>Date Of Birth</b>&nbsp;<span
                                                style="color:red;">*
                                            </span></label>
                                        <input type="date" name="date_of_birth" class="form-control"
                                            id="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>">
                                        <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <label class="form-label" for="current_location"><b>Current
                                                Location</b>&nbsp;<span style="color:red;">*
                                            </span></label>
                                        <input type="text" name="current_location" class="form-control"
                                            id="current_location" value="<?php echo e(old('current_location')); ?>"
                                            placeholder="Enter current location">
                                        <?php $__errorArgs = ['current_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label class="form-label">
                                            <b>
                                                About me
                                                <span style="color:red;"><b>*</b></span>
                                            </b>
                                        </label>
                                        <textarea id="about_me" name="about_me" class="form-control">
                                            
                                         </textarea>
                                         <?php $__errorArgs = ['about_me'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                         <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <label class="form-label" for="height"><b>Height (CM)</b></label>
                                        <input type="text" name="height" class="form-control" id="height"
                                            value="<?php echo e(old('height')); ?>" placeholder="Enter height">

                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <label class="form-label" for="weight"><b>Weight (KG)</b></label>
                                        <input type="text" name="weight" class="form-control" id="weight"
                                            value="<?php echo e(old('weight')); ?>" placeholder="Enter weight">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <label class="form-label" for="images"><b>Image </b>&nbsp;<span
                                                style="color:red;">*
                                            </span></label>
                                        <input type="file" name="images[]" multiple class="form-control">
                                        <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                  <div class="col-md-6 col-lg-6 col-sm-6">
                                        <div class="form-group">
                                            <label class="form-label" for="images"><b>Work Reel 1</b></label>
                                            <input type="text" class="form-control" name="work_reel1"
                                                placeholder="Work Reel 1"
                                                value="<?php echo e(old('work_reel1')); ?>"/>
                                            <?php $__errorArgs = ['work_reel1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger">
                                                    <?php echo e($message); ?>

                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                  </div>
                               
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <label class="form-label" for="images"><b>Work Reel 2</b></label>
                                        <input type="text" class="form-control" name="work_reel2"
                                            placeholder="Work Reel 2"
                                            value="<?php echo e(old('work_reel2')); ?>" />
                                        <?php $__errorArgs = ['work_reel2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                              </div>
                               <div class="col-md-6 col-lg-6 col-sm-6">
                                        <div class="form-group">
                                            <label class="form-label" for="images"><b>Work Reel 3</b></label>
                                            <input type="text" class="form-control" name="work_reel3"
                                                placeholder="Work Reel 3"
                                                value="<?php echo e(old('work_reel3')); ?>" />
                                            <?php $__errorArgs = ['work_reel3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger">
                                                    <?php echo e($message); ?>

                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                </div>
                               
                            </div>
                            <center>
                                <input type="submit" class="btn btn-danger" value="Save" />
                            </center>
                        </form>
                        <hr />
                        <div class="row">
                            <div class="col-lg-6">

                            </div>
                            <div class="col-lg-6">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="<?php echo e(asset('assets/intl-telephone/js/intlTelInput.js')); ?>" type="text/javascript"></script>
    <script>
        var selectedFlag = 'in'
        $("#mobile_number").intlTelInput({
            //preferredCountries: ['in','ae', 'us'],
            preferredCountries: ['in', 'ae', 'us'],
            autoPlaceholder: true,
            separateDialCode: true,
            // onlyCountries: ['in','ae', 'us'],
            initialCountry: selectedFlag,
            utilsScript: '<?php echo e(asset('assets/intl-telephone/js/utils.js')); ?>'
        });
        $("#mobile_number").on("countrychange", function(e, countryData) {
            $("#phone_country_code").val(countryData.dialCode);
        });

        /*Summernotes*/
           $(document).ready(function() {
            $('#about_me').summernote({
                placeholder: 'Enter movie description goes here..',
                // tabsize: 2,
                height: 300,
                // followingToolbar: true,
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'underline', 'clear']],
                    ['fontname', ['fontname']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['table', ['table']],
                    ['insert', ['link', 'picture', 'video']],
                    ['view', ['fullscreen', 'codeview', 'help']],
                ],
                popover: {
                    image: [
                        ['image', ['resizeFull', 'resizeHalf', 'resizeQuarter', 'resizeNone']],
                        ['float', ['floatLeft', 'floatRight', 'floatNone']],
                        ['remove', ['removeMedia']]
                    ],
                    link: [
                        ['link', ['linkDialogShow', 'unlink']]
                    ],
                    table: [
                        ['add', ['addRowDown', 'addRowUp', 'addColLeft', 'addColRight']],
                        ['delete', ['deleteRow', 'deleteCol', 'deleteTable']],
                    ],
                    air: [
                        ['color', ['color']],
                        ['font', ['bold', 'underline', 'clear']],
                        ['para', ['ul', 'paragraph']],
                        ['table', ['table']],
                        ['insert', ['link', 'picture']]
                    ]
                }

            })
            //.summernote("code", '<?php echo old('policy', isset($item->policy) ? $item->policy : ''); ?>');

            // var postForm = function() {
            //     var content = $('textarea[name="policy"]').html($('#policycontent').code());
            // }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\anticasting_web_profile_management\app\Modules/Actors/resources/views/ManageActor/create.blade.php ENDPATH**/ ?>