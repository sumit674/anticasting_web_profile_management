
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/auth/toastr.min.css')); ?>">
<script src="<?php echo e(asset('assets/auth/toastr.min.js')); ?>"></script>
<?php $__env->startSection('content'); ?>
    <section class="contact-us section">
        <?php if(Session::has('message')): ?>
            <div id="success" title="Success">
                <p><?php echo e(Session::get('message')); ?></p>
            </div>
        <?php elseif(Session::has('error')): ?>
            <div id="error" title="Error">
                <p><?php echo e(Session::get('error')); ?></p>
            </div>
        <?php endif; ?>
        <script>
            <?php if(Session::has('msg')): ?>
               toastr.success("<?php echo e(Session::get('msg')); ?>");
                 <?php elseif(Session::has('expire')): ?>
                 toastr.info("<?php echo e(Session::get('expire')); ?>");
                 <?php elseif(Session::has('invalid')): ?>
                 toastr.error("<?php echo e(Session::get('invalid')); ?>");
                 <?php elseif(Session::has('success')): ?>
                 toastr.success("<?php echo e(Session::get('success')); ?>");
             <?php endif; ?>
         </script>
        <main class="d-flex align-items-center w-auto main-container">
            <div class="container">
                <div class="card login-card">
                    <div class="row no-gutters">
                        <div class="col-md-5">
                            <div class="card-body">
                                <div class="brand-wrapper">
                                    <a href="<?php echo e(route('users.home')); ?>">
                                        <img src="<?php echo e(asset('assets/website/images/anticasting-logo.png')); ?>" alt="logo"
                                            class="logo">
                                    </a>
                                </div>
                                <p class="d-flex justify-content-center fs-4">OTP Verification</p>
                                <div class="border-0">
                                    <span class="text-muted">Please enter OTP, which is sent on your email address.</span>
                                </div>
                                <form class="form-disable" action="<?php echo e(route('verify.otp')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div>&nbsp;</div>
                                    <div class="form-group form mb-3">
                                        <label for="otp" class="text-muted" >OTP Number</label>
                                        <br/>
                                        <input class="form-control" id="otp" name="otp" maxlength="4" type="text" placeholder="Please enter otp" />

                                        <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="text-danger"><b><?php echo e($message); ?></b></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="d-grid gap-2 mb-1 mt-4 col-6 mx-auto">
                                        <input type="submit" class="btn btn-dark form-control" type="submit" value="Verify OTP">
                                    </div>
                                </form>
                                <div class="mt-3">
                                    <p class="login-card-footer-text"><b>Don't have an account?</b><a
                                            href="<?php echo e(route('users.register')); ?>" class="text-reset text-muted"> Register
                                            here</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <img src="<?php echo e(asset('assets/website/images/banner.jpg')); ?>" alt="login"
                                class="login-card-img">
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script type="text/javascript">
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\anticasting_web_profile_management\resources\views/auth/otp.blade.php ENDPATH**/ ?>