<header class="header">
    <div class="navbar-area shadow-sm bg-body rounded">
        <div class="container">
        <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand logo" href="<?php echo e(url('/')); ?>">
                <!-- <img class=logo1 src="assets/images/logo/logo.svg" alt=Logo data-pagespeed-url-hash=1728553520 onload="pagespeed.CriticalImages.checkImageForCriticality(this);" /> -->
                <img src="<?php echo e(asset('./assets/website/images/anticasting-logo.png')); ?>" alt="<?php echo e(Config::get('name', 'Anti-Casting')); ?>">
            </a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbar"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="toggler-icon"></span>
                <span class="toggler-icon"></span>
                <span class="toggler-icon"></span>
            </button>
            <div id="navbar"class="collapse navbar-collapse justify-content-end">
                <ul id="nav"class="navbar-nav">
                    <li class="nav-item">
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/about')); ?>">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/our-work')); ?>">Our Work</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/contact')); ?>">Contact</a>
                    </li>
                      <?php if(auth()->guard()->check()): ?>
                      <li class="nav-item">
                        <a  href="<?php echo e(route('users.view-profile')); ?>">View Profile</a>
                    </li>
                        <li class="nav-item">
                            <a  href="<?php echo e(route('users.submitProfile')); ?>">Submit Profile</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('users.logout')); ?>">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('users.login')); ?>">Login</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
        </div>
     </div>
</header>
<?php /**PATH F:\wamp64\www\anticasting_web_profile_management\resources\views/include/submitprofile/header.blade.php ENDPATH**/ ?>