
<?php $__env->startSection('title'); ?>
    Manage Bucket
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main">

        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4 p-r-0 title-margin-right">
                    <div class="page-header">
                        <div class="page-title">
                            <h1>Manage Bucket</h1>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 p-r-0 title-margin-right">
                    <div class="page-header">
                        <div class="page-title">
                           <a href="<?php echo e(route('admin.bucket.manage.create')); ?>" class="btn btn-primary">Add Bucket</a>
                        </div>
                    </div>
                </div>
               <div class="col-lg-4 p-l-0 title-margin-left">
                    <div class="page-header">
                        <div class="page-title">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active">Manage Bucket</li>
                            </ol>
                        </div>
                    </div>
                </div> 
            </div>

            <!-- /# row -->
            <section id="main-content"> 
                 <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-title pr">
                                <h6><b class="breadcrumb-item">Bucket</b></h6>
                            </div>
                            <hr />
                            <div class="card-body">
                            <div class="table-responsive">
                                    <table class="table table-striped table-borderless">
                                        <thead>
                                            <tr>
                                                <th class="text-center">Id</th>
                                                <th class="text-center">Bucket</th>
                                                <th class="text-center">Movie</th>
                                                <th class="text-center">Move Link</th>
                                                <th class="text-center">Description</th>
                                                <th class="text-center">Action</th>
                                              
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td class="text-center"><?php echo e($key + 1); ?></td>
                                                        <td class="text-center">
                                                        
                                                            <?php echo e($item->bucket_name); ?> 
                                                        </td>
                                                        <td class="text-center"><?php echo e($item->movie_name); ?></td>
                                                        <td class="text-center">
                                                            <a class="text-truncate" href="<?php echo e($item->movie_link); ?>"></a>
                                                            <?php echo e($item->movie_link); ?>

                                                        </td>
                                                        <td class="text-center">
                                                          <?php echo $item->description; ?>

                                                        </td>
                                                        
                                                         <td class="text-center">
                                                            <a href="<?php echo e(route('admin.bucket.manage.edit', $item->id)); ?>"
                                                                class="btn btn-success btn-sm">
                                                                <i class="fa-solid fa-pen-to-square"></i>
                                                            </a>
                                                            <a href="<?php echo e(route('admin.bucket.manage.details', $item->id)); ?>"
                                                                class="btn btn-primary btn-sm">
                                                                <i class="fa-solid fa-eye"></i>
                                                            </a>
                                                            <a href="<?php echo e(route('admin.bucket.manage.delete', $item->id)); ?>" class="btn btn-danger btn-sm">
                                                                <i class="fa-solid fa-trash-arrow-up"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="7" class="text-center">No Record</td>
                                                    </tr>
                                                <?php endif; ?>
                                       </tbody>
                                    </table>
                                 </div>
                                <div>
                                   <?php echo e($items->links('pagination::bootstrap-5')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\anticasting_web_profile_management\app\Modules/Bucket/resources/views/index.blade.php ENDPATH**/ ?>