<footer class="footer">
    <div class="footer-bottom">
        <div class="container">
            <div class="inner">
                <div class="row">
                    <div class="col-12">
                        <div class="left">
                            <p>
                                Copyrights @ www.anticasting.in
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH F:\wamp64\www\anticasting_web_profile_management\resources\views/include/submitprofile/footer.blade.php ENDPATH**/ ?>