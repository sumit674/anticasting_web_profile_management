<footer class="footer">
    <div class="footer-bottom">
        <div class="container">
            <div class="inner">
                <div class="row">
                    <div class="col-12">
                        <div class="left">
                            <p>
                                Copyrights @ www.anticasting.in
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>