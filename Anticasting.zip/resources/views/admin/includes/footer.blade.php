<div class="row">
    <div class="col-lg-12">
        <div class="footer">
            <p>2022 © Admin Board. - <a href="#">cyantron.com</a></p>
        </div>
    </div>
</div>
