<?php

return [
    'welcome' => 'Welcome, this is Message module.'
];
