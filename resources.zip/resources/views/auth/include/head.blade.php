<link href="https://fonts.googleapis.com/css?family=Karla:400,700&display=swap" rel="stylesheet"/>
<link href="{{ asset('assets/auth/new-auth/css/materialdesignicons.min.css') }}" rel="stylesheet"/>
{{-- <link href="{{ asset('assets/auth/new-auth/css/bootstrap.min.css') }}" rel="stylesheet"/> --}}
<link href="{{ asset('assets/users/assets/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('assets/auth/new-auth/css/style.css') }}" rel="stylesheet"/>
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
<link rel="stylesheet" href="{{asset('assets/website/css/alertbox.css')}}"/>
